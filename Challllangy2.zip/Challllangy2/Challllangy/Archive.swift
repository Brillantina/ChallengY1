//
//  Archive.swift
//  Challllangy
//
//  Created by Giulls on 28/10/22.
//

import SwiftUI

struct Archive: View {
    
    @StateObject var vm = CoreDataViewModel()
    @ObservedObject var activityManager: ActivityManager
    @State private var addActivityModalPresented = false
    
    var body: some View {
        NavigationView {//potrebbe essere qui problema
            VStack {
                
                List {
//                    Section(header: Text("")) {
//                        ForEach($activityManager) { activity in
//
//                            NavigationLink(activity.title, destination: EditActivityView())
//                        }.onDelete(perform: activityManager.deleteActivity)
//                    }
                    
                    ForEach(vm.savedEntities)
                    {
                        NoteEntity in
                        Text(NoteEntity.title ?? "")
                            .onTapGesture {
                                vm.updateNote(entity: NoteEntity)
                            }
                    }.onDelete(perform: vm.deleteNote)
                  
                }.listStyle(.insetGrouped)
            }.navigationTitle("Accepted Challenges")
        }
    }
}

struct Archive_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}
