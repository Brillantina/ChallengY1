//
//  ChallllangyApp.swift
//  Challllangy
//
//  Created by Giulls on 28/10/22.
//

import SwiftUI


@main
struct ChallllangyApp: App {

    var body: some Scene {
        WindowGroup {
            ContentView()
              
        }
    }
}
