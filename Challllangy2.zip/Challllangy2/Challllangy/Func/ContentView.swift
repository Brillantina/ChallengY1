//
//  ContentView.swift
//  Challllangy
//
//  Created by Giulls on 28/10/22.
//

import SwiftUI
import SpriteKit
import AVFoundation



extension UserDefaults {
    var onboardingViewShown: Bool{
        get {
            return (UserDefaults.standard.value(forKey: "onboardingViewShown")
                    as? Bool) ?? false
        }
        set {
            UserDefaults.standard.setValue(newValue , forKey: "onboardingViewShown")
        }
    }
}

struct ContentView: View {

    var body: some View {
        
        if UserDefaults.standard.onboardingViewShown  {
            HomePage()
        } else {
            OnboardingManager()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
