//
//  ActivityManager.swift
//  Challllangy
//
//  Created by Giulls on 30/10/22.
//
import Foundation
import CoreData
import SwiftUI

class ActivityManager: ObservableObject {
    
    let containter: NSPersistentContainer
    
    @Published var savedEntities: [NoteEntity] = []
    @StateObject var vm = CoreDataViewModel()
    
    init()
    {
        containter = NSPersistentContainer(name: "NoteContainer")
        containter.loadPersistentStores {(description, error) in
            if let error = error
            {
                print("ERROR \(error)")
            }
            else
            {
                print("Ok ")
            }
            
            //            adddebugact()
        }
        fetchNotes()
    }
        //debug
        
        
        
        //    func adddebugact() {
        //        activities.append(Activity(title: "", longDescription: ""))
        //    }
        //    func addActivity(activity: Activity) {
        //        activities.append(activity)
        //    }
        //    func deleteActivity(activity: Activity) {
        //        activities.removeAll(where: {$0.id == activity.id})
        //    }
        //    func deleteActivity(at offsets: IndexSet) {
        //        activities.remove(atOffsets: offsets)
        //    }
   
    
    func fetchNotes()
    {
        let request = NSFetchRequest<NoteEntity>(entityName:"NoteEntity")
        do {
            savedEntities = try containter.viewContext.fetch(request)
        }
        catch let error {
            print("Error fetching\(error)")
        }
    }
    
    func addNote(text: String)
    {
        let newNote = NoteEntity(context: containter.viewContext)
//        newNote.date = Date()
        newNote.title = text
        saveNote()
    }
    
    func saveNote()
    {
        do {
            try containter.viewContext.save()
            fetchNotes()
        }
        catch let error {
            print("error saving \(error)")
        }
    }
    
    func updateNote (entity: NoteEntity)
    {
        let currentTitle = entity.title ?? ""
        let newTitle = currentTitle + "!"
        entity.title = newTitle
        saveNote()
    }
    
    func deleteNote(indexSet: IndexSet)
    {
        guard let index = indexSet.first else { return }
        let entity = savedEntities[index]
        containter.viewContext.delete(entity)
        saveNote()
    }
    
    
    
    
}


