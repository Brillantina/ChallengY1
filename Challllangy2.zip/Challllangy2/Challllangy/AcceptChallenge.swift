//
//  AcceptChallenge.swift
//  Challllangy
//
//  Created by Giulls on 29/10/22.
//

import SwiftUI

struct AcceptChallenge: View {
    @ObservedObject var activityManager: ActivityManager
    @ObservedObject var myViewModel = ViewModel()
    @StateObject var vm = CoreDataViewModel()
    @State var textField: String = ""
    //    @State var textField1: String = ""
    //    @State var data: Data
    //    @State private var newActivity = Activity(
    //        title: "",
    //        longDescription: ""
    //    )
    @State var showView : Bool
    @State private var isAddButtonDisabled = true
    @State private var addAlertShowed = false
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        NavigationView {
            
            ZStack {
                Color("CustomWhite")
                    .ignoresSafeArea()
                
                VStack (spacing: 100){
                    Spacer()
                    
                    Text(myViewModel.challenge)
                        .fontWeight(.heavy)
                        .padding()
                        .frame(width: 360, height: 120)
                        .cornerRadius(16)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .background(
                            Capsule().strokeBorder(Color.white, lineWidth: 0)
                                .background(.black)
                                .cornerRadius(20)
                        )
                    
                    //MARK: - TEXTEDITOR CON PLACEHOLDER
                    
                    
                    ZStack (alignment: .topLeading){
                        
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(.white)
                        
                        
                        
                        VStack {
                            
                            TextField("",text: $textField)
                                .disableAutocorrection(true)
                                .padding(.leading, 4)
                                .lineLimit(4)
                            
                        }
                        if
                            textField.isEmpty {
                            Text("Write your thoughts about this challenge")
                                .foregroundColor(.gray)
                                .padding(.top, 12)
                                .padding(.leading, 8)
                        }
                    }
                    .multilineTextAlignment(.leading)
                    .frame(width: 360, height: 109)
                    .cornerRadius(16)
                    
                    Spacer()
                    
                        .toolbar {
                            ToolbarItem(placement: .navigationBarLeading) {
                                Button("Cancel") {
                                    showView.toggle()
                                    presentationMode.wrappedValue.dismiss()
                                    
                                }
                            }
                            
                            //MARK: - ALERT
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(action: {
                                    addAlertShowed.toggle()
                                }, label: {
                                    Text("Add")
                                        .fontWeight(.semibold)
                                        .disabled(textField.isEmpty)
                                }).alert("Do you want to save it?", isPresented: $addAlertShowed) {
                                    Button("Cancel", role: .cancel) {}
                                    Button(action: {
                                        guard !textField.isEmpty else {return}
                                        vm.addNote(text: textField)
                                        textField = ""
                                        
                                        
                                        showView.toggle()
                                        presentationMode.wrappedValue.dismiss()
                                        //                                        activityManager.addActivity(activity: newActivity)
                                        //
                                        //                                        showView.toggle()
                                        //                                        presentationMode.wrappedValue.dismiss() //questo è magico
                                    }, label: {
                                        Text("Yes")
                                    })
                                    List
                                    {
                                        ForEach(vm.savedEntities)
                                        {
                                            NoteEntity in
                                            Text(NoteEntity.title ?? "ciao")
                                                .onTapGesture {
                                                    vm.updateNote(entity: NoteEntity)
                                                }
                                        }.onDelete(perform: vm.deleteNote)
                                    }.listStyle(PlainListStyle())
                                }.navigationTitle("Notes")      // alert
                            }
                        }
                }
            }
            .onTapGesture {
                self.hideKeyboard() }
            
        }
    }
}

struct AcceptChallenge_preview: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}
