//
//  ChallengeModel.swift
//  Challllangy
//
//  Created by Giulls on 30/10/22.
//

import Foundation

struct Activity: Identifiable {
    
    let id = UUID()
    var title: String
    var longDescription: String
    
}
