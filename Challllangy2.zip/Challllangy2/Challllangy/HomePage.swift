//
//  HomePage.swift
//  Challllangy
//
//  Created by Giulls on 28/10/22.
//

import SwiftUI

struct HomePage: View {
    
    @ObservedObject var myViewModel = ViewModel()
    @State var showView = false
    @State private var isAddButtonDisabled = true
    @ObservedObject var activityManager = ActivityManager()

    var body: some View {
        
        NavigationView {
            // MARK: - GENERATE BUTTON
            
            Button  {
                
                showView.toggle()
                
            } label:
            {
                ZStack {
                    
                    Circle()
                        .frame(width: 260, height: 260)
                        .foregroundColor(.black)
                    
                    Text("Generate")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .font(.largeTitle)
                    
                }
                .sheet(isPresented: $showView) {
                    AcceptChallenge(activityManager: activityManager, showView: true)
                }
            }
            
            // MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(trailing:
                                    Button(action: {
                print("Archivio")
            }, label: {
                NavigationLink(destination: Archive(activityManager: activityManager)
                    .navigationBarBackButtonHidden(false))
                {
                    Image (systemName: "note.text")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.black)
                }
            }))
            
            
        } //: NavigationView
    }
}



struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}
