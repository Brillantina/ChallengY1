//
//  TextEditorManager.swift
//  Challllangy
//
//  Created by Giulls on 30/10/22.
//

import SwiftUI


// MARK: TEXT FIELD LIMIT

struct TextFieldLimitModifer: ViewModifier {
    @Binding var value: String
    var length: Int

    func body(content: Content) -> some View {
        content
            .onReceive(value.publisher.collect()) {
                value = String($0.prefix(length))
            } // questo probabilmente serve per lo storage???
    }
}

extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
