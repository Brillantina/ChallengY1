//
//  OnboardingFourth.swift
//  Challllangy
//
//  Created by Giulls on 28/10/22.
//

import SwiftUI

struct OnboardingFourth: View {
    
    @State private var isAnimating : Bool = false
    
    var body: some View {
        
        VStack (spacing: 50) {
            
            Image ("Welcome")
                .resizable()
                .scaledToFit()
                .frame(height:450)
                .opacity(isAnimating ? 1 : 0)
                .offset(y: isAnimating ? 0 : -40)
                .animation(.easeOut(duration: 3), value: isAnimating)
            
            Button(action: {
                print("Funziona?")
            }, label: {
                NavigationLink(destination: HomePage()
                    .navigationBarBackButtonHidden(true))
                {
                    Text ("Explore")
                        .font(.title)
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .frame(width: 360, height: 65, alignment: .center)
                }
            })
            .background(
                Capsule().strokeBorder(Color.black, lineWidth: 0)
                    .background(.black))
            .cornerRadius(20)
            .opacity(isAnimating ? 1 : 0)
            .offset(y: isAnimating ? 0 : 40)
            .animation(.easeOut(duration: 2), value: isAnimating)
        }
        .onAppear(perform: {
            withAnimation(.easeIn(duration: 3)){
                isAnimating = true
            }
    })  
    }
    
}

struct OnboardingFourth_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingFourth()
    }
}
