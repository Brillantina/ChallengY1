//
//  OnboardingManager.swift
//  Challllangy
//
//  Created by Giulls on 28/10/22.
//

import SwiftUI

struct OnboardingManager: View {
    
    @AppStorage("onboardingViewShown")
    var onboardingViewShown : Bool = false
    
    var body: some View {
        
        NavigationView {
            
            
            TabView {
                
                OnboardingFirst()
                
                OnboardingSecond()
                
                OnboardingThird()
                
                OnboardingFourth()
            }
            .ignoresSafeArea()
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
            .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
        }
        .onAppear(perform: {
            UserDefaults.standard.onboardingViewShown = true
            
        })
    }
}

struct OnboardingManager_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingManager()
    }
}
