//
//  OnboardingFirst.swift
//  Challllangy
//
//  Created by Giulls on 28/10/22.
//

import SwiftUI

struct OnboardingFirst: View {
    var body: some View {
        
        VStack (alignment: .center) {
            
            Image("w3")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .padding()
            
            Text("Welcome to Challengy")
                .font(.title)
                .multilineTextAlignment(.center)
                .padding()
            
            Text("Get yourself involved in this human interaction based experience! Follow the steps and jump into the ChallengY space!")
                .font(.body)
                .fontWeight(.light)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
                .padding()
            
        } //: VStack
    }
}

struct OnboardingFirst_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingFirst()
    }
}
