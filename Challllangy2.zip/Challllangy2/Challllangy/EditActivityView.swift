//
//  EditActivityView.swift
//  Challllangy
//
//  Created by Giulls on 30/10/22.
//

import SwiftUI

struct EditActivityView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct EditActivityView_Previews: PreviewProvider {
    static var previews: some View {
        EditActivityView()
    }
}
